"""src URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Client.models import Cuser
from Client.views import Signup,Login,chome,ALogin,ASignup,register,welcome,search ,UesrCaseList
from advocate.views import InClist,history,accept,profileUpdate,Alogout,reject,rejectList
# from Aprofile.views import areg

urlpatterns = [
    path("",welcome),
    path('admin/', admin.site.urls),
    path("reg/",Signup,name="signup"),
    path("log/",Login,name="Login"),
    path("areg/",ASignup,name="asignup"),
    path("alog/",ALogin,name="alogin"),
    path("home/",chome,name="chome"),
    path("ahome/",InClist,name="ahome"),
    path("casereg/<str:ad>",register,name="case-reg"),
    path("ucase/",UesrCaseList,name="clist"),
    path('ahis/',history,name="hist"),
    path('acc/<int:id>',accept,name='accept'),
    path('rej/<int:id>',reject,name='reject'),
    path('aprofile/',profileUpdate,name="profile"),
    path('logout/',Alogout,name="Logout"),
    path('query/',search,name="search"),
    path("rejl/",rejectList,name="rejl"),

    
]
