from django.apps import AppConfig


class AdvocateConfig(AppConfig):
    name = 'advocate'
