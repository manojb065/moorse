from django.contrib import admin
from .models import aprofile,history_accept,history_reject
# Register your models here.

admin.site.register(aprofile)
admin.site.register(history_accept)
admin.site.register(history_reject)