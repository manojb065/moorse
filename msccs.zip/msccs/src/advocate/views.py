from django.shortcuts import redirect, render
from Client.models import CaseList, Cuser
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from .models import aprofile
from .forms import update,Cupdate
from django.contrib.auth import logout
import os
from src import settings
from django.core.paginator import Paginator
from .models import history_accept,history_reject
# Create your views here.

@login_required(login_url="alogin")
def InClist(request):
    res=CaseList.objects.filter(advocate=request.user , status=False)
    alist=[]
    for i in range(0,len(res)-1,2):
        alist.append([res[i],res[i+1]])
    if len(res)%2!=0:
        alist.append([res[len(res)-1],None])
    paginator = Paginator(alist, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    res=page_obj.paginator.count
    context={"page_obj":page_obj}
    return render(request,"Creq.html",context)

def history(request):
    res=history_accept.objects.filter(advocate=request.user)
    alist=[]
    for i in range(0,len(res)-1,2):
        alist.append([res[i],res[i+1]])
    print (alist)
    if len(res)%2!=0:
        alist.append([res[len(res)-1],None])
    paginator = Paginator(alist, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    res=page_obj.paginator.count
    context={"page_obj":page_obj}
    # context={'list':accepted}
    return render(request,"history.html",context)

def accept(request,id):
    accepted=CaseList.objects.filter(id=id).first()
    accepted.status=True
    accepted.save()
    h=history_accept(client=accepted.client,advocate=Cuser.objects.filter(name=accepted.advocate).first(),email=accepted.email)
    h.save()
    send_mail(
    'case accepted',
    'your case has been accepted by  advocate {} '.format(request.user),
    None,
    [accepted.email],
    fail_silently=False,)
    return redirect('ahome')

def profileUpdate(request):
    if request.method == "POST":
        form=Cupdate(request.POST,instance=Cuser.objects.filter(name=request.user).first())
        form2=update(request.POST,instance=aprofile.objects.filter(user=request.user.aprofile.user).first())
        if form.is_valid() and form2.is_valid():
            print(form.cleaned_data,form2.cleaned_data,"******************")
            form.save()
            form2.save()
        return redirect('ahome')
    else:
        form2=Cupdate(instance=Cuser.objects.filter(name=request.user).first())
        form=update(instance=aprofile.objects.filter(user=request.user.aprofile.user).first())
        form2.fields['name'].widget.attrs['readonly'] = True
        form2.fields['email'].widget.attrs['readonly'] = True
    context={'form':form,'form2':form2}
    return render(request,"profile.html",context)

def Alogout(request):
    res=request.user.staff
    logout(request)
    if res:
        return redirect("alogin")
    return redirect('Login')

def reject(request,id):
    rejected=CaseList.objects.filter(id=id).first()
    h=history_reject(client=rejected.client,advocate=Cuser.objects.filter(name=rejected.advocate).first(),email=rejected.email)
    h.save()
    root="/media/"
    os.remove(os.path.join(settings.MEDIA_ROOT, str(rejected.doc)))
    rejected.delete()
    send_mail(
    'case rejected',
    'your case has been rejected by  advocate {} '.format(request.user),
    None,
    [rejected.email],
    fail_silently=False,)
    return redirect('ahome')

def rejectList(request):
    res = history_reject.objects.filter(advocate=request.user)
    alist = []
    for i in range(0, len(res) - 1, 2):
        alist.append([res[i], res[i + 1]])
    print(alist)
    if len(res) % 2 != 0:
        alist.append([res[len(res) - 1], None])
    paginator = Paginator(alist, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    res = page_obj.paginator.count
    context = {"page_obj": page_obj}
    # context={'list':accepted}
    return render(request, "Rhistory.html", context)


