from django import forms
from .models import aprofile
from Client.models import Cuser


class update(forms.ModelForm):
    class Meta:
        model= aprofile
        fields = ['case','exprience','fee']

class Cupdate(forms.ModelForm):
    class Meta:
        model= Cuser
        fields = ['name','email','phone','address']
        
