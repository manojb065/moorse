from django.db import models
from Client.models import Cuser

# Create your models here.

class aprofile(models.Model):
    user=models.OneToOneField(Cuser,on_delete=models.CASCADE,primary_key=True)
    casetype=(("civil","civil appeal"),("commerical","commerical appeal"),("criminal","criminal appeal"),("divorce","divorce appeal"),("election","election appeal"),("Matrimonial","Matrimonial  appeal"))
    case=models.CharField(choices=casetype,max_length=20)
    exprience=models.IntegerField()
    fee=models.IntegerField(default=2000)


    def __str__(self):
        return '{}'.format(self.user)

class history_accept(models.Model):
    advocate=models.ForeignKey(Cuser,on_delete=models.CASCADE)
    client=models.CharField(max_length=20)
    time=models.DateTimeField(auto_now_add=True)
    email=models.EmailField()

    def __str__(self):
        return "{} - {} - {}".format(self.advocate,self.client,self.time)
    
class history_reject(models.Model):
    advocate=models.ForeignKey(Cuser,on_delete=models.CASCADE)
    client=models.CharField(max_length=20)
    time=models.DateTimeField(auto_now_add=True)
    email=models.EmailField()

    def __str__(self):
        return "{} - {} - {}".format(self.advocate,self.client,self.time)



