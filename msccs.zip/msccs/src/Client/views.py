from django.shortcuts import render,redirect
from .forms import SignupForm,LoginForm,registerForm
from django.contrib.auth import authenticate,login
from django.contrib.auth.decorators import login_required
from advocate.models import aprofile
from .models import CaseList,Cuser
from django.core.mail import send_mail
from django.db.models import Q
from django.core.paginator import Paginator

def Signup(request):
    
    if request.method =="POST":
        form=SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("Login")
    
    else:
        form=SignupForm()
    context={"form":form}
    return render(request,"cregister.html",context)

def Login(request):
    if request.method == "POST":
        form=LoginForm(request.POST)
        if form.is_valid():
            user=authenticate(email=form.cleaned_data['email'],password=form.cleaned_data['password'])
            if user and user.staff==False:
                if  user is not None:
                    login(request,user)
                    return redirect("chome")
                else:
                    return redirect('Login')
            else:
                return redirect('alogin')
    else:
        form=LoginForm()
    return render(request,"Clogin.html",{"form":form})

@login_required(login_url="Login")
def chome(request):
    res=aprofile.objects.all()
    alist=[]
    for i in range(0,len(res)-1,2):
        alist.append([res[i],res[i+1]])
    if len(res)%2!=0:
        alist.append([res[len(res)-1],None])
    paginator = Paginator(alist, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    res=page_obj.paginator.count
    context={"page_obj":page_obj}
    return render(request,"srchadv.html",context)

def ASignup(request):
    
    if request.method =="POST":
        print()
        for i in request.POST:
            print(request.POST[i],"****")
        user=Cuser(name=request.POST['name'],phone=request.POST['phone'],address=request.POST['address'],email=request.POST['email'],staff=True)
        user.set_password(request.POST[i])
        user.save()
        aprofile(user=user,case=request.POST['case'],exprience=request.POST['exprience'],fee=request.POST['fee']).save()
        return redirect("alogin")
    
    else:
        form=SignupForm()
    context={"form":form}
    return render(request,"Eregister.html",context)

def ALogin(request):
    if request.method == "POST":
        form=LoginForm(request.POST)
        if form.is_valid():
            user=authenticate(email=form.cleaned_data['email'],password=form.cleaned_data['password'])
            if user  and user.staff==True:
                if  user is not None:
                    login(request,user)
                    return redirect("ahome")
                else:
                    return redirect('alogin')
            else:
                return redirect('Login')
    else:
        form=LoginForm()
    return render(request,"Elogin.html",{"form":form})




def register(request,ad):
    if request.method == "POST":
        form=registerForm(request.POST,request.FILES)
        if form.is_valid():
            ad=Cuser.objects.filter(name=ad).first()
            adv=aprofile.objects.filter(user=ad)
            print()
            print(ad,adv)
            case=CaseList(client=request.user,advocate=adv[0],doc=form.cleaned_data.get('doc'),description=form.cleaned_data['description'],
            caset=form.cleaned_data['caset'],phone=int(form.cleaned_data['phone']),email=request.user.email)
            case.save()
            
            send_mail(
    'case registered',
    'your case has been successfully registered to {} with case type of {}'.format(adv[0].user.name,form.cleaned_data['caset']),
    None,
    [request.user.email],
    fail_silently=False,)
            return redirect("chome")
    else:
        form=registerForm()
    context={"form":form}
    return render(request,"casereg.html",context)
            
def UesrCaseList(request):
    list = CaseList.objects.filter(client=request.user)
    context={'list':list}
    return render(request,"Chistory.html",context)

def welcome(request):
    return render(request,"welcom.html")

def search(request):
    template='srchadv.html'
    query=request.GET.get('q')
    try:
        res=int(query)
        result=aprofile.objects.filter(Q(fee__lte=query)| Q(exprience__gte=query))
    except ValueError:
        res=query
        result=aprofile.objects.filter(Q(user__name__icontains=query) | Q(case__icontains=query)) 
    alist=[]
    for i in range(0,len(result)-1,2):
        alist.append([result[i],result[i+1]])
    if len(result)%2!=0:
        alist.append([result[len(result)-1],None])
    paginator = Paginator(alist, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    res=page_obj.paginator.count
    context={"page_obj":page_obj}
    return render(request,template,context)

