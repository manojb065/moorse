from django.db import models
# Create your models here.



from django.contrib.auth.models import AbstractBaseUser,BaseUserManager,PermissionsMixin
from django.conf import settings

class CustUserManager(BaseUserManager):
    def create_user(self,name,email,phone,password):
        if not name:
            raise ValueError("name is required")
        if not email:
            raise ValueError("email is required")
        user=self.model(
            email=self.normalize_email(email=email),
            name=name,
            phone=phone,
        )

        user.set_password(raw_password=password)
        user.save(using=self._db)
        return user
    def create_staff(self,name,email,phone,password):
        user=self.create_user(name=name,email=email,phone=phone,password=password)
        user.is_staff=True
        user.save(using=self._db)
        return user
    def create_superuser(self,name,email,phone,password):
        user=self.create_user(name=name,email=email,phone=phone,password=password)
        user.is_admin=True
        user.is_staff=True
        user.is_superuser=True

        user.save(using=self._db)
        return user

class Cuser(AbstractBaseUser,PermissionsMixin):
    name=models.CharField(max_length=20,verbose_name='name',unique=True,primary_key=True)
    address=models.TextField()
    email=models.CharField(max_length=50,unique=True,verbose_name='email id')
    phone=models.CharField(max_length=10)
    active = models.BooleanField(default=True)
    staff=models.BooleanField(default=False)
    admin=models.BooleanField(default=False)
    superuser = models.BooleanField(default=False)

    objects=CustUserManager()

    USERNAME_FIELD='email'
    REQUIRED_FIELDS = ['name','phone']
    EMAIL_FIELD='email'

    def __str__(self):
        return self.name
    def get_short_name(self):
        return self.name
    def get_full_name(self):
        return self.name
    def is_admin(self):
        return self.is_admin

    def is_staff(self):
        return self.is_staff

    # def is_admin(self):
    #     return self.is_admin

    @staticmethod
    def has_perm(perm, obj=None):
        # "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    @staticmethod
    def has_module_perms(app_label):
        # "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True



class CaseList(models.Model):
    client=models.ForeignKey(Cuser,on_delete=models.CASCADE)
    advocate=models.CharField(max_length=40)
    doc=models.FileField(upload_to="casefiles/")
    description=models.TextField(max_length=200)
    caset=models.CharField(max_length=20)
    phone=models.CharField(max_length=10)
    email=models.EmailField()
    status=models.BooleanField(default=False)

    def __str__(self):
        return "{} - {} -{}".format(self.client,self.caset,self.advocate)